import React, { Component } from 'react'
import { MDBNavbar, MDBNavbarBrand, MDBNavbarNav, MDBNavItem, MDBNavLink, MDBNavbarToggler, MDBCollapse, MDBDropdown,
    MDBDropdownToggle, MDBDropdownMenu, MDBDropdownItem, MDBIcon,MDBBtn } from "mdbreact";
import { BrowserRouter as Router } from 'react-router-dom';
import {Link} from 'react-router-dom'
export default class header extends Component {
    state = {
        isOpen: false
      };
      toggleCollapse = () => {
        this.setState({ isOpen: !this.state.isOpen });
      }
    render() {
        return (
          <div>
            <MDBNavbar color="default-color" dark expand="md">
              <MDBNavbarBrand>
               <img style={{width:'55px'}} src={'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTo_dqh7lQJrg4qHnuXpRPc93LObfGGRjK--JzRcQffDPiXvjr8'}/>
              </MDBNavbarBrand>
              <MDBNavbarToggler onClick={this.toggleCollapse} />
              <MDBCollapse id="navbarCollapse3" isOpen={this.state.isOpen} navbar>
                <MDBNavbarNav left>
                  <MDBNavItem active>
                    <MDBNavLink to="#!">Hotels</MDBNavLink>
                  </MDBNavItem>
                  <MDBNavItem>
                    <MDBNavLink to="#!">Food</MDBNavLink>
                  </MDBNavItem>
                  <MDBNavItem>
                    <MDBNavLink to="#!">Vacations</MDBNavLink>
                  </MDBNavItem>
                  
                </MDBNavbarNav>
                <MDBNavbarNav right>
                
                <Link to= '/login'>
                  <MDBBtn>
                 
                     Login
                
                  </MDBBtn>
                  </Link>
                  <Link to= '/register'>
                  <MDBBtn>
                
                     Register
                    
                  </MDBBtn>
                  </Link>
                  
                </MDBNavbarNav>
              </MDBCollapse>
            </MDBNavbar>
            </div>
        )
    }
}
