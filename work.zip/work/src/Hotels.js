import React, { Component } from 'react'
import axios from 'axios';
import { MDBBtn, MDBCard, MDBCardBody, MDBCardImage, MDBCardTitle, MDBCardText, MDBCol, MDBRow, MDBContainer } from 'mdbreact';
export default class Hotels extends Component {
  completeData;

  constructor(props) {
    super(props);
    this.state = { person: [] };
  }

  componentDidMount() {
    axios.get(`https://jsonplaceholder.typicode.com/users`)
      .then(res => {
        const persons = res.data;
        this.completeData = persons
        this.setState({ person: persons });
      })
  }



  book = () => {
    alert('SAMPLE DATA')
  }

  filterData(event) {
    let filterData = [];
    this.completeData.map(item => {
      if (item.name.toLowerCase().includes(event.target.value.toLowerCase())) {
        filterData.push(item);
      }
    })
    if (event.target.value.length) {
      this.setState({ person: filterData })
    } else {
      this.setState({ person: this.completeData })
    }

  }

  render() {
    return (

      <>
        <form >
          <input onKeyUp={(e) => this.filterData(e)} type="text" placeholder="Search" aria-label="Search" />
        </form>
        <MDBContainer>
          <MDBRow>


            {this.state.person.map(item => {
              return (
                <>
                  <MDBCard style={{ width: "22rem" }} className={"cardspace"}>
                    <div style={{ height: '140px', position: 'relative' }}>
                      <MDBCardImage className="img-fluid" src="https://i.pinimg.com/originals/c3/c1/48/c3c1480b7e1fdfd821c49d8d46c00be6.jpg" waves />
                    </div>
                    <MDBCardBody>
                      <MDBCardTitle>{item.name}</MDBCardTitle>
                      <MDBCardText>
                        Some quick example text to build on the card title and make
                        up the bulk of the card&apos;s content.
          </MDBCardText>
                      <MDBBtn onClick={this.book}>Book Now</MDBBtn>
                    </MDBCardBody>
                  </MDBCard>
                </>
              )
            })}
          </MDBRow>
        </MDBContainer>
      </>
    )

  }
}
