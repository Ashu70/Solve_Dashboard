import React from 'react';
import { BrowserRouter, Route, Switch, Redirect } from 'react-router-dom';
import LoginForm from './LoginForm'
import Dashboard from './Dashboard'
import Register from './Register'
function Routes() {
    return (
        <>
            <BrowserRouter>
                <Switch>
                    <Route exact path="/login" component={LoginForm} />
                    <Route exact path="/dashboard" component={Dashboard} />  
                    <Route exact path="/register" component={Register}/>                  
                    <Redirect to="/register" from="/" />

                </Switch>
            </BrowserRouter>
        </>
    );
}
export default Routes;