import React, { Component } from 'react'
import { MDBContainer, MDBRow, MDBCol, MDBBtn, MDBInput } from 'mdbreact';
import {Link} from 'react-router-dom'
import './index.css'
export default class Register extends Component {
    login_form =() =>{
        alert('You are Registered, Please Sign-in to continue')
    }
    render() {
        return (
            <div className="reg">
    
      <form>
        <p className="h5 text-center mb-4">Register</p>
        <div className="grey-text">
          <MDBInput label="Your name" icon="user" group type="text" validate error="wrong"
            success="right" />
          <MDBInput label="Your email" icon="envelope" group type="email" validate error="wrong"
            success="right" />
             <MDBInput label="Your password" icon="lock" group type="password" validate />
          <MDBInput label="Retype Password" icon="exclamation-triangle" group type="password" validate
            />
         
        </div>
        <div className="text-center">
        <Link to='/login'>
          <MDBBtn onClick={this.login_form} color="primary">Register</MDBBtn>
          </Link>
        </div>
      </form>
            </div>
        )
    }
}
