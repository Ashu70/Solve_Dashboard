import React from 'react';
import logo from './logo.svg';
import './App.css';
import Route from './Routes'
import Login from './LoginForm'

function App() {
  return (
    <div className="App">
     <Route/>
    </div>
  );
}

export default App;
