import React from 'react'
import Header from './Header/header'
import Hotels from './Hotels'
import Dropdown from './Dropdown' 
export default function Dashboard() {
    return (
        <div>
            <Header/>
            <br/>
            <Dropdown/>
            <br/>
            <Hotels/>
       
        </div>
    )
}
