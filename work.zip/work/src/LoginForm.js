import React, { Component } from 'react';
import {
    MDBInput,
    MDBBtn,
    MDBCard,
    MDBCardBody
} from 'mdbreact';
import {Link} from 'react-router-dom'
import './index.css'

class LoginForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            userid: '',
            password: '',
        };
    }

    handleuser = e => {
        this.setState({
           userid: e.target.value
           
        });
    };

    handlepass = e => {
        this.setState({
           password: e.target.value
           
        });
    };

    // handleSubmit = event => {
    //     event.preventDefault();
    //         this.setState({
    //         userid: '',
    //         password: '',
    //     });
    // };

    renderRedirect = () => {
       window.location.href = "/dashboard"
           
        
    };

    render() {
       
        return (
            <MDBCard className="card--wrap">
                <MDBCardBody className="mx-4">
                    <form onSubmit={this.handleSubmit}>
                        <div className="text-center">
                            <h3 className="dark-grey-text mb-5">
                                <strong>
                                    Login Here
                                </strong>
                            </h3>
                        </div>
                        <MDBInput
                            label="Enter Email ID"
                            icon="user"
                            group
                            type="text"
                            validate
                            error="wrong"
                            success="right"
                            name="userid"
                            value={this.state.userid}
                            onChange={this.handleuser}
                        />
                        <MDBInput
                            label="Enter Password"
                            icon="lock"
                            group
                            type="password"
                            validate
                            name="password"
                            value={this.state.password}
                            onChange={this.handlepass}
                        />
                        {/* <p className="font-small blue-text d-flex justify-content-end pb-3">
                            <a
                                href="forgotpassword"
                                className="blue-text ml-1"
                            >
                                Forgot Password?
                            </a>
                        </p> */}
                        <Link to= '/dashboard'>
                        <div className="text-center mb-3">
                            <MDBBtn
                                type="submit"
                                gradient="blue"
                                rounded
                                className="btn-block z-depth-1a"
                                onClick={this.renderRedirect}
                            >
                                Sign in
                            </MDBBtn>
                        </div></Link>
                    </form>
                </MDBCardBody>
            </MDBCard>
        );
    }
}

export default LoginForm;
