import React from 'react'
import { MDBDropdown, MDBDatePicker, MDBIcon, MDBDropdownToggle, MDBDropdownMenu, MDBDropdownItem, MDBContainer, MDBRow, MDBCol } from "mdbreact";
export default function Dropdown() {
  return (
    <MDBContainer>
      <MDBRow>
        <MDBCol size="2">
          <MDBDropdown>
            <MDBDropdownToggle caret color="primary">
              State
      </MDBDropdownToggle>
            <MDBDropdownMenu basic>
              <MDBDropdownItem>Delhi Ncr</MDBDropdownItem>
              <MDBDropdownItem>Mumbai</MDBDropdownItem>
              <MDBDropdownItem>Punjab</MDBDropdownItem>
              <MDBDropdownItem divider />
              <MDBDropdownItem>Coming soon to your city</MDBDropdownItem>
            </MDBDropdownMenu>
          </MDBDropdown>
        </MDBCol>




        <MDBCol size="2">

          <MDBDropdown>
            <MDBDropdownToggle caret color="primary">
              Date
      </MDBDropdownToggle>
            <MDBDropdownMenu basic>
              <MDBDropdownItem>SAMPLE DATA</MDBDropdownItem>
            </MDBDropdownMenu>
          </MDBDropdown>
        </MDBCol>
        <MDBCol size="8">

        </MDBCol>
      </MDBRow>
    </MDBContainer>

  )
}
